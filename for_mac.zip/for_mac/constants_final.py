# Files used
FILENAME_JSON = ''   # .json file to 
FILENAME_CSV = 'SQL'                        # CSV file to be written and send.
EXTENSION_CSV = '.csv'                 # json extension

# location of PHP script
WP_URL = 'http://bcausam.co.uk/charities-tables-update/'

# Array of folders on a remote server
FTP_PATH = ['clickandbuilds', 'Bcausam', 'wp-content', 'themes', 'astra']
GUI_FTP_PATH = "clickandbuilds,Bcausam,wp-content,themes,astra"

# SFTP account credentials
FTP_HOST = 'access834021495.webspace-data.io'
FTP_USERNAME = 'u101433123'
FTP_PASSWORD = ''                       # note that storing password in the text is not safe
FTP_PORT = 22
